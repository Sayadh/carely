/* Reference taxonomy and Armenian administrative geography (localized). */

export type T3 = { hy: string; ru: string; en: string };

export interface CategorySeed {
  slug: string;
  name: T3;
  description: T3;
  services: { slug: string; name: T3; requiredQualification?: 'NURSING_LICENSE' }[];
  attributes: { slug: string; group: 'AGE_GROUP' | 'CARE_FORMAT' | 'TASK' | 'SETTING' | 'ANIMAL_TYPE' | 'ANIMAL_SIZE'; name: T3 }[];
}

export const CATEGORIES: CategorySeed[] = [
  {
    slug: 'childcare',
    name: { hy: 'Երեխաների խնամք', ru: 'Уход за детьми', en: 'Childcare' },
    description: {
      hy: 'Դայակներ և բեյբիսիթերներ՝ կարճաժամկետ, մշտական կամ գիշերային խնամքի համար։',
      ru: 'Няни и бебиситтеры для разового, регулярного или ночного ухода.',
      en: 'Nannies and babysitters for occasional, regular or overnight care.',
    },
    services: [
      { slug: 'babysitting', name: { hy: 'Բեյբիսիթինգ', ru: 'Бебиситтинг', en: 'Babysitting' } },
      { slug: 'regular-nanny', name: { hy: 'Մշտական դայակ', ru: 'Постоянная няня', en: 'Regular nanny' } },
      { slug: 'night-nanny', name: { hy: 'Գիշերային դայակ', ru: 'Ночная няня', en: 'Night nanny' } },
      { slug: 'school-escort', name: { hy: 'Ուղեկցում դպրոց և խմբակներ', ru: 'Сопровождение в школу и кружки', en: 'School and activity escort' } },
    ],
    attributes: [
      { slug: 'age-infant', group: 'AGE_GROUP', name: { hy: 'Մինչև 1 տարեկան', ru: 'До 1 года', en: 'Under 1 year' } },
      { slug: 'age-toddler', group: 'AGE_GROUP', name: { hy: '1–3 տարեկան', ru: '1–3 года', en: '1–3 years' } },
      { slug: 'age-preschool', group: 'AGE_GROUP', name: { hy: '3–6 տարեկան', ru: '3–6 лет', en: '3–6 years' } },
      { slug: 'age-school', group: 'AGE_GROUP', name: { hy: '6 տարեկանից բարձր', ru: 'От 6 лет', en: '6 years and older' } },
      { slug: 'child-short-term', group: 'CARE_FORMAT', name: { hy: 'Կարճաժամկետ', ru: 'Разово', en: 'Short-term' } },
      { slug: 'child-regular', group: 'CARE_FORMAT', name: { hy: 'Մշտական', ru: 'Регулярно', en: 'Regular' } },
      { slug: 'child-night', group: 'CARE_FORMAT', name: { hy: 'Գիշերային', ru: 'Ночью', en: 'Overnight' } },
      { slug: 'child-meals', group: 'TASK', name: { hy: 'Սննդի պատրաստում', ru: 'Приготовление еды', en: 'Meal preparation' } },
      { slug: 'child-homework', group: 'TASK', name: { hy: 'Օգնություն դասերին', ru: 'Помощь с уроками', en: 'Homework help' } },
      { slug: 'child-activities', group: 'TASK', name: { hy: 'Զբոսանք և խաղեր', ru: 'Прогулки и игры', en: 'Walks and play' } },
    ],
  },
  {
    slug: 'elderly-care',
    name: { hy: 'Տարեցների խնամք', ru: 'Уход за пожилыми', en: 'Elderly care' },
    description: {
      hy: 'Ամենօրյա օգնություն, ընկերակցություն, ցերեկային և գիշերային խնամք։',
      ru: 'Ежедневная помощь, компания, дневной и ночной уход.',
      en: 'Daily assistance, companionship, daytime and overnight care.',
    },
    services: [
      { slug: 'elderly-daily-assistance', name: { hy: 'Ամենօրյա օգնություն', ru: 'Ежедневная помощь', en: 'Daily assistance' } },
      { slug: 'elderly-companionship', name: { hy: 'Ընկերակցություն', ru: 'Компания и общение', en: 'Companionship' } },
      { slug: 'elderly-day-care', name: { hy: 'Ցերեկային խնամք', ru: 'Дневной уход', en: 'Daytime care' } },
      { slug: 'elderly-night-care', name: { hy: 'Գիշերային խնամք', ru: 'Ночной уход', en: 'Overnight care' } },
    ],
    attributes: [
      { slug: 'elderly-companionship-task', group: 'TASK', name: { hy: 'Ընկերակցություն', ru: 'Общение', en: 'Companionship' } },
      { slug: 'elderly-hygiene', group: 'TASK', name: { hy: 'Օգնություն հիգիենայում', ru: 'Помощь с гигиеной', en: 'Hygiene assistance' } },
      { slug: 'elderly-mobility', group: 'TASK', name: { hy: 'Օգնություն տեղաշարժվելիս', ru: 'Помощь в передвижении', en: 'Mobility support' } },
      { slug: 'elderly-meals', group: 'TASK', name: { hy: 'Սննդի պատրաստում', ru: 'Приготовление еды', en: 'Meal preparation' } },
      { slug: 'elderly-errands', group: 'TASK', name: { hy: 'Գնումներ և գործեր', ru: 'Покупки и поручения', en: 'Shopping and errands' } },
      { slug: 'elderly-at-home', group: 'SETTING', name: { hy: 'Տանը', ru: 'На дому', en: 'At home' } },
      { slug: 'elderly-in-hospital', group: 'SETTING', name: { hy: 'Հիվանդանոցում', ru: 'В больнице', en: 'In hospital' } },
    ],
  },
  {
    slug: 'patient-care',
    name: { hy: 'Հիվանդների խնամք', ru: 'Уход за больными', en: 'Patient care' },
    description: {
      hy: 'Ոչ բժշկական օգնություն և առանձին նշված որակավորված բուժքույրական ծառայություններ։',
      ru: 'Немедицинская помощь и отдельно отмеченные услуги квалифицированных медсестёр.',
      en: 'Non-medical assistance and separately identified qualified nursing services.',
    },
    services: [
      { slug: 'patient-assistance', name: { hy: 'Ոչ բժշկական խնամք', ru: 'Немедицинский уход', en: 'Non-medical patient assistance' } },
      { slug: 'hospital-companion', name: { hy: 'Ուղեկցում հիվանդանոցում', ru: 'Сопровождение в больнице', en: 'Hospital companion' } },
      { slug: 'recovery-support', name: { hy: 'Աջակցություն վերականգնման ընթացքում', ru: 'Поддержка в период восстановления', en: 'Recovery support' } },
      {
        slug: 'nursing-care',
        name: { hy: 'Բուժքույրական խնամք', ru: 'Сестринский уход', en: 'Nursing care' },
        requiredQualification: 'NURSING_LICENSE',
      },
    ],
    attributes: [
      { slug: 'patient-hygiene', group: 'TASK', name: { hy: 'Օգնություն հիգիենայում', ru: 'Помощь с гигиеной', en: 'Hygiene assistance' } },
      { slug: 'patient-mobility', group: 'TASK', name: { hy: 'Օգնություն տեղաշարժվելիս', ru: 'Помощь в передвижении', en: 'Mobility support' } },
      { slug: 'patient-companionship', group: 'TASK', name: { hy: 'Ընկերակցություն', ru: 'Общение', en: 'Companionship' } },
      { slug: 'patient-at-home', group: 'SETTING', name: { hy: 'Տանը', ru: 'На дому', en: 'At home' } },
      { slug: 'patient-in-hospital', group: 'SETTING', name: { hy: 'Հիվանդանոցում', ru: 'В больнице', en: 'In hospital' } },
      { slug: 'patient-night', group: 'CARE_FORMAT', name: { hy: 'Գիշերային', ru: 'Ночью', en: 'Overnight' } },
    ],
  },
  {
    slug: 'pet-care',
    name: { hy: 'Կենդանիների խնամք', ru: 'Уход за животными', en: 'Pet care' },
    description: {
      hy: 'Զբոսանքներ, այցեր տուն և ժամանակավոր խնամք։',
      ru: 'Выгул, визиты на дом и временная передержка.',
      en: 'Walks, home visits and temporary boarding.',
    },
    services: [
      { slug: 'dog-walking', name: { hy: 'Շների զբոսանք', ru: 'Выгул собак', en: 'Dog walking' } },
      { slug: 'pet-home-visits', name: { hy: 'Այցեր տուն', ru: 'Визиты на дом', en: 'Home visits' } },
      { slug: 'pet-boarding', name: { hy: 'Ժամանակավոր խնամք', ru: 'Передержка', en: 'Temporary boarding' } },
    ],
    attributes: [
      { slug: 'pet-dogs', group: 'ANIMAL_TYPE', name: { hy: 'Շներ', ru: 'Собаки', en: 'Dogs' } },
      { slug: 'pet-cats', group: 'ANIMAL_TYPE', name: { hy: 'Կատուներ', ru: 'Кошки', en: 'Cats' } },
      { slug: 'pet-small', group: 'ANIMAL_TYPE', name: { hy: 'Փոքր կենդանիներ', ru: 'Мелкие животные', en: 'Small pets' } },
      { slug: 'pet-birds', group: 'ANIMAL_TYPE', name: { hy: 'Թռչուններ', ru: 'Птицы', en: 'Birds' } },
      { slug: 'pet-size-small', group: 'ANIMAL_SIZE', name: { hy: 'Փոքր չափսի', ru: 'Маленького размера', en: 'Small size' } },
      { slug: 'pet-size-medium', group: 'ANIMAL_SIZE', name: { hy: 'Միջին չափսի', ru: 'Среднего размера', en: 'Medium size' } },
      { slug: 'pet-size-large', group: 'ANIMAL_SIZE', name: { hy: 'Մեծ չափսի', ru: 'Крупного размера', en: 'Large size' } },
    ],
  },
];

export interface RegionSeed {
  slug: string;
  name: T3;
  children: { slug: string; type: 'CITY' | 'DISTRICT'; name: T3 }[];
}

/** Yerevan (with its 12 administrative districts) and the 10 marzes with major towns. */
export const REGIONS: RegionSeed[] = [
  {
    slug: 'yerevan',
    name: { hy: 'Երևան', ru: 'Ереван', en: 'Yerevan' },
    children: [
      { slug: 'yerevan-ajapnyak', type: 'DISTRICT', name: { hy: 'Աջափնյակ', ru: 'Аджапняк', en: 'Ajapnyak' } },
      { slug: 'yerevan-arabkir', type: 'DISTRICT', name: { hy: 'Արաբկիր', ru: 'Арабкир', en: 'Arabkir' } },
      { slug: 'yerevan-avan', type: 'DISTRICT', name: { hy: 'Ավան', ru: 'Аван', en: 'Avan' } },
      { slug: 'yerevan-davtashen', type: 'DISTRICT', name: { hy: 'Դավթաշեն', ru: 'Давташен', en: 'Davtashen' } },
      { slug: 'yerevan-erebuni', type: 'DISTRICT', name: { hy: 'Էրեբունի', ru: 'Эребуни', en: 'Erebuni' } },
      { slug: 'yerevan-kanaker-zeytun', type: 'DISTRICT', name: { hy: 'Քանաքեռ-Զեյթուն', ru: 'Канакер-Зейтун', en: 'Kanaker-Zeytun' } },
      { slug: 'yerevan-kentron', type: 'DISTRICT', name: { hy: 'Կենտրոն', ru: 'Кентрон', en: 'Kentron' } },
      { slug: 'yerevan-malatia-sebastia', type: 'DISTRICT', name: { hy: 'Մալաթիա-Սեբաստիա', ru: 'Малатия-Себастия', en: 'Malatia-Sebastia' } },
      { slug: 'yerevan-nork-marash', type: 'DISTRICT', name: { hy: 'Նորք-Մարաշ', ru: 'Норк-Мараш', en: 'Nork-Marash' } },
      { slug: 'yerevan-nor-nork', type: 'DISTRICT', name: { hy: 'Նոր Նորք', ru: 'Нор-Норк', en: 'Nor Nork' } },
      { slug: 'yerevan-nubarashen', type: 'DISTRICT', name: { hy: 'Նուբարաշեն', ru: 'Нубарашен', en: 'Nubarashen' } },
      { slug: 'yerevan-shengavit', type: 'DISTRICT', name: { hy: 'Շենգավիթ', ru: 'Шенгавит', en: 'Shengavit' } },
    ],
  },
  {
    slug: 'aragatsotn',
    name: { hy: 'Արագածոտնի մարզ', ru: 'Арагацотнская область', en: 'Aragatsotn Province' },
    children: [
      { slug: 'ashtarak', type: 'CITY', name: { hy: 'Աշտարակ', ru: 'Аштарак', en: 'Ashtarak' } },
      { slug: 'aparan', type: 'CITY', name: { hy: 'Ապարան', ru: 'Апаран', en: 'Aparan' } },
      { slug: 'talin', type: 'CITY', name: { hy: 'Թալին', ru: 'Талин', en: 'Talin' } },
    ],
  },
  {
    slug: 'ararat',
    name: { hy: 'Արարատի մարզ', ru: 'Араратская область', en: 'Ararat Province' },
    children: [
      { slug: 'artashat', type: 'CITY', name: { hy: 'Արտաշատ', ru: 'Арташат', en: 'Artashat' } },
      { slug: 'ararat-city', type: 'CITY', name: { hy: 'Արարատ', ru: 'Арарат', en: 'Ararat' } },
      { slug: 'masis', type: 'CITY', name: { hy: 'Մասիս', ru: 'Масис', en: 'Masis' } },
      { slug: 'vedi', type: 'CITY', name: { hy: 'Վեդի', ru: 'Веди', en: 'Vedi' } },
    ],
  },
  {
    slug: 'armavir',
    name: { hy: 'Արմավիրի մարզ', ru: 'Армавирская область', en: 'Armavir Province' },
    children: [
      { slug: 'armavir-city', type: 'CITY', name: { hy: 'Արմավիր', ru: 'Армавир', en: 'Armavir' } },
      { slug: 'vagharshapat', type: 'CITY', name: { hy: 'Վաղարշապատ', ru: 'Вагаршапат', en: 'Vagharshapat' } },
      { slug: 'metsamor', type: 'CITY', name: { hy: 'Մեծամոր', ru: 'Мецамор', en: 'Metsamor' } },
    ],
  },
  {
    slug: 'gegharkunik',
    name: { hy: 'Գեղարքունիքի մարզ', ru: 'Гегаркуникская область', en: 'Gegharkunik Province' },
    children: [
      { slug: 'gavar', type: 'CITY', name: { hy: 'Գավառ', ru: 'Гавар', en: 'Gavar' } },
      { slug: 'sevan', type: 'CITY', name: { hy: 'Սևան', ru: 'Севан', en: 'Sevan' } },
      { slug: 'martuni', type: 'CITY', name: { hy: 'Մարտունի', ru: 'Мартуни', en: 'Martuni' } },
      { slug: 'vardenis', type: 'CITY', name: { hy: 'Վարդենիս', ru: 'Варденис', en: 'Vardenis' } },
      { slug: 'chambarak', type: 'CITY', name: { hy: 'Ճամբարակ', ru: 'Чамбарак', en: 'Chambarak' } },
    ],
  },
  {
    slug: 'kotayk',
    name: { hy: 'Կոտայքի մարզ', ru: 'Котайкская область', en: 'Kotayk Province' },
    children: [
      { slug: 'hrazdan', type: 'CITY', name: { hy: 'Հրազդան', ru: 'Раздан', en: 'Hrazdan' } },
      { slug: 'abovyan', type: 'CITY', name: { hy: 'Աբովյան', ru: 'Абовян', en: 'Abovyan' } },
      { slug: 'charentsavan', type: 'CITY', name: { hy: 'Չարենցավան', ru: 'Чаренцаван', en: 'Charentsavan' } },
      { slug: 'yeghvard', type: 'CITY', name: { hy: 'Եղվարդ', ru: 'Егвард', en: 'Yeghvard' } },
      { slug: 'nor-hachn', type: 'CITY', name: { hy: 'Նոր Հաճն', ru: 'Нор Ачин', en: 'Nor Hachn' } },
      { slug: 'tsaghkadzor', type: 'CITY', name: { hy: 'Ծաղկաձոր', ru: 'Цахкадзор', en: 'Tsaghkadzor' } },
    ],
  },
  {
    slug: 'lori',
    name: { hy: 'Լոռու մարզ', ru: 'Лорийская область', en: 'Lori Province' },
    children: [
      { slug: 'vanadzor', type: 'CITY', name: { hy: 'Վանաձոր', ru: 'Ванадзор', en: 'Vanadzor' } },
      { slug: 'alaverdi', type: 'CITY', name: { hy: 'Ալավերդի', ru: 'Алаверди', en: 'Alaverdi' } },
      { slug: 'stepanavan', type: 'CITY', name: { hy: 'Ստեփանավան', ru: 'Степанаван', en: 'Stepanavan' } },
      { slug: 'spitak', type: 'CITY', name: { hy: 'Սպիտակ', ru: 'Спитак', en: 'Spitak' } },
    ],
  },
  {
    slug: 'shirak',
    name: { hy: 'Շիրակի մարզ', ru: 'Ширакская область', en: 'Shirak Province' },
    children: [
      { slug: 'gyumri', type: 'CITY', name: { hy: 'Գյումրի', ru: 'Гюмри', en: 'Gyumri' } },
      { slug: 'artik', type: 'CITY', name: { hy: 'Արթիկ', ru: 'Артик', en: 'Artik' } },
      { slug: 'maralik', type: 'CITY', name: { hy: 'Մարալիկ', ru: 'Маралик', en: 'Maralik' } },
    ],
  },
  {
    slug: 'syunik',
    name: { hy: 'Սյունիքի մարզ', ru: 'Сюникская область', en: 'Syunik Province' },
    children: [
      { slug: 'kapan', type: 'CITY', name: { hy: 'Կապան', ru: 'Капан', en: 'Kapan' } },
      { slug: 'goris', type: 'CITY', name: { hy: 'Գորիս', ru: 'Горис', en: 'Goris' } },
      { slug: 'sisian', type: 'CITY', name: { hy: 'Սիսիան', ru: 'Сисиан', en: 'Sisian' } },
      { slug: 'kajaran', type: 'CITY', name: { hy: 'Քաջարան', ru: 'Каджаран', en: 'Kajaran' } },
      { slug: 'meghri', type: 'CITY', name: { hy: 'Մեղրի', ru: 'Мегри', en: 'Meghri' } },
    ],
  },
  {
    slug: 'vayots-dzor',
    name: { hy: 'Վայոց ձորի մարզ', ru: 'Вайоцдзорская область', en: 'Vayots Dzor Province' },
    children: [
      { slug: 'yeghegnadzor', type: 'CITY', name: { hy: 'Եղեգնաձոր', ru: 'Ехегнадзор', en: 'Yeghegnadzor' } },
      { slug: 'vayk', type: 'CITY', name: { hy: 'Վայք', ru: 'Вайк', en: 'Vayk' } },
      { slug: 'jermuk', type: 'CITY', name: { hy: 'Ջերմուկ', ru: 'Джермук', en: 'Jermuk' } },
    ],
  },
  {
    slug: 'tavush',
    name: { hy: 'Տավուշի մարզ', ru: 'Тавушская область', en: 'Tavush Province' },
    children: [
      { slug: 'ijevan', type: 'CITY', name: { hy: 'Իջևան', ru: 'Иджеван', en: 'Ijevan' } },
      { slug: 'dilijan', type: 'CITY', name: { hy: 'Դիլիջան', ru: 'Дилижан', en: 'Dilijan' } },
      { slug: 'berd', type: 'CITY', name: { hy: 'Բերդ', ru: 'Берд', en: 'Berd' } },
      { slug: 'noyemberyan', type: 'CITY', name: { hy: 'Նոյեմբերյան', ru: 'Ноемберян', en: 'Noyemberyan' } },
    ],
  },
];
