import { Controller, Get, Injectable, Module } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import type { CategoryDto, I18nText, LocationDto, QualificationKind } from '@carely/shared';
import { PrismaService } from '../common/prisma.service';

export function i18n(rows: { locale: string; name: string }[] | undefined): I18nText {
  const out: I18nText = {};
  for (const r of rows ?? []) if (r.name) out[r.locale as keyof I18nText] = r.name;
  return out;
}
export function i18nDesc(rows: { locale: string; description: string }[] | undefined): I18nText {
  const out: I18nText = {};
  for (const r of rows ?? []) if (r.description) out[r.locale as keyof I18nText] = r.description;
  return out;
}

@Injectable()
export class TaxonomyService {
  private cache: { at: number; categories: CategoryDto[]; locations: LocationDto[] } | null = null;
  constructor(private readonly prisma: PrismaService) {}

  invalidate() {
    this.cache = null;
  }

  private async load() {
    if (this.cache && Date.now() - this.cache.at < 60_000) return this.cache;
    const [cats, locs] = await Promise.all([
      this.prisma.category.findMany({
        where: { active: true },
        orderBy: [{ sortOrder: 'asc' }, { slug: 'asc' }],
        include: {
          translations: true,
          services: { where: { active: true }, orderBy: [{ sortOrder: 'asc' }, { slug: 'asc' }], include: { translations: true } },
          attributes: { where: { active: true }, orderBy: [{ group: 'asc' }, { sortOrder: 'asc' }], include: { translations: true } },
        },
      }),
      this.prisma.location.findMany({ where: { active: true }, orderBy: [{ sortOrder: 'asc' }, { slug: 'asc' }], include: { translations: true } }),
    ]);
    const categories: CategoryDto[] = cats.map((c) => ({
      id: c.id,
      slug: c.slug,
      name: i18n(c.translations),
      description: i18nDesc(c.translations),
      services: c.services.map((s) => ({ id: s.id, slug: s.slug, categoryId: c.id, name: i18n(s.translations), requiredQualification: s.requiredQualification as QualificationKind | null })),
      attributes: c.attributes.map((a) => ({ id: a.id, slug: a.slug, categoryId: c.id, group: a.group, name: i18n(a.translations) })),
    }));
    const locations: LocationDto[] = locs.map((l) => ({ id: l.id, slug: l.slug, type: l.type, parentId: l.parentId, name: i18n(l.translations) }));
    this.cache = { at: Date.now(), categories, locations };
    return this.cache;
  }

  async categories() {
    return (await this.load()).categories;
  }
  async locations() {
    return (await this.load()).locations;
  }

  /** Location with all ancestors and descendants (for service-area matching). */
  async locationFamily(slugOrId: string): Promise<{ target: LocationDto; ids: string[]; ancestors: string[]; descendants: string[] } | null> {
    const all = await this.locations();
    const target = all.find((l) => l.slug === slugOrId || l.id === slugOrId);
    if (!target) return null;
    const ancestors: string[] = [];
    let p = target.parentId;
    while (p) {
      ancestors.push(p);
      p = all.find((l) => l.id === p)?.parentId ?? null;
    }
    const descendants: string[] = [];
    const walk = (id: string) => {
      for (const c of all.filter((l) => l.parentId === id)) {
        descendants.push(c.id);
        walk(c.id);
      }
    };
    walk(target.id);
    return { target, ids: [target.id, ...ancestors, ...descendants], ancestors, descendants };
  }
}

@ApiTags('taxonomy')
@Controller('taxonomy')
export class TaxonomyController {
  constructor(private readonly service: TaxonomyService) {}

  @Get('categories')
  categories() {
    return this.service.categories();
  }

  @Get('locations')
  locations() {
    return this.service.locations();
  }
}

@Module({ controllers: [TaxonomyController], providers: [TaxonomyService], exports: [TaxonomyService] })
export class TaxonomyModule {}
