<script setup lang="ts">
import { Info } from 'lucide-vue-next';
import { createRequestSchema, utcToZonedDate, addDays, LIMITS } from '@carely/shared';
import type { ProfessionalProfileDto } from '@carely/shared';

const props = defineProps<{ pro: ProfessionalProfileDto }>();
const { t } = useI18n();
const { tx, price, weekday } = useFormat();
const api = useApi();
const auth = useAuthStore();
const toast = useToast();
const errMsg = useErrorMessage();
const localePath = useLocalePath();
const route = useRoute();
const { locations, load } = useTaxonomy();
await load().catch(() => undefined);

const today = utcToZonedDate(new Date());
const { state: form, clear } = useDraft(`request:${props.pro.slug}`, () => ({
  serviceId: props.pro.services[0]?.service.id ?? '',
  scheduleType: 'ONE_TIME' as 'ONE_TIME' | 'RECURRING',
  date: addDays(today, 1),
  startDate: addDays(today, 1),
  endDate: addDays(today, 14),
  weekdays: [] as number[],
  startTime: '10:00',
  endTime: '14:00',
  locationId: '',
  addressNote: '',
  requirements: '',
}));

// Only the professional's declared service areas (and places inside them) can be chosen.
const areaIds = computed(() => (locations.value ?? []).filter((l) => props.pro.serviceAreas.some((a) => a.slug === l.slug)).map((l) => l.id));
const locationOptions = useLocationOptions(areaIds, 'id');
const selectedService = computed(() => props.pro.services.find((s) => s.service.id === form.value.serviceId));
const { errors, set: setErrors, fromZod, clear: clearErrors } = useFieldErrors();
const formError = ref('');
const busy = ref(false);
const overnight = computed(() => form.value.endTime <= form.value.startTime);

async function submit() {
  clearErrors();
  formError.value = '';
  const payload = {
    professionalSlug: props.pro.slug,
    serviceId: form.value.serviceId,
    scheduleType: form.value.scheduleType,
    ...(form.value.scheduleType === 'ONE_TIME' ? { date: form.value.date } : { startDate: form.value.startDate, endDate: form.value.endDate, weekdays: form.value.weekdays }),
    startTime: form.value.startTime,
    endTime: form.value.endTime,
    locationId: form.value.locationId,
    addressNote: form.value.addressNote,
    requirements: form.value.requirements,
  };
  const parsed = createRequestSchema.safeParse(payload);
  if (!parsed.success) {
    fromZod(parsed.error.issues);
    formError.value = t('request.fixErrors');
    return;
  }
  if (!auth.user) {
    // The draft is kept in session storage; sign-in returns here and reopens the panel.
    const back = `${route.path}?request=1`;
    return navigateTo({ path: localePath('/auth/login'), query: { redirect: back, reason: 'request' } });
  }
  busy.value = true;
  try {
    const res = await api<{ id: string }>('/requests', { method: 'POST', body: payload });
    clear();
    toast.success(t('request.sent'));
    await navigateTo(localePath(`/requests/${res.id}`));
  } catch (e) {
    setErrors(e);
    formError.value = errMsg(e);
  } finally {
    busy.value = false;
  }
}
</script>

<template>
  <form class="space-y-4" novalidate @submit.prevent="submit">
    <div>
      <p class="text-sm text-muted">{{ t('card.from') }}</p>
      <p class="text-xl font-semibold">{{ price(selectedService?.price ?? pro.price) }}</p>
    </div>

    <UiSelect v-model="form.serviceId" :label="t('request.service')" :error="errors.serviceId" :options="pro.services.map((s) => ({ value: s.service.id, label: `${tx(s.service.name)} — ${price(s.price)}` }))" required />

    <fieldset>
      <legend class="field-label">{{ t('request.scheduleType') }}</legend>
      <div class="grid grid-cols-2 gap-1 rounded-[var(--radius-control)] bg-bg p-1">
        <label v-for="opt in ['ONE_TIME', 'RECURRING']" :key="opt" class="flex min-h-10 cursor-pointer items-center justify-center rounded-lg text-sm font-medium has-[:checked]:bg-surface has-[:checked]:text-primary has-[:checked]:shadow-[var(--shadow-card)] has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-primary-ring">
          <input v-model="form.scheduleType" type="radio" :value="opt" class="sr-only" />
          {{ t(`request.type.${opt}`) }}
        </label>
      </div>
    </fieldset>

    <UiDateField v-if="form.scheduleType === 'ONE_TIME'" v-model="form.date" :label="t('request.date')" :min="today" :error="errors.date" required />
    <template v-else>
      <div class="grid grid-cols-2 gap-3">
        <UiDateField v-model="form.startDate" :label="t('request.startDate')" :min="today" :error="errors.startDate" required />
        <UiDateField v-model="form.endDate" :label="t('request.endDate')" :min="form.startDate" :max="addDays(form.startDate, LIMITS.recurringMaxWeeks * 7)" :error="errors.endDate" required />
      </div>
      <fieldset>
        <legend class="field-label">{{ t('request.weekdays') }}</legend>
        <div class="flex flex-wrap gap-1.5">
          <label v-for="d in 7" :key="d" class="flex min-h-10 min-w-11 cursor-pointer items-center justify-center rounded-lg border border-line-strong px-2 text-sm has-[:checked]:border-primary has-[:checked]:bg-primary-soft has-[:checked]:text-primary has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-primary-ring">
            <input v-model="form.weekdays" type="checkbox" :value="d" class="sr-only" />{{ weekday(d) }}
          </label>
        </div>
        <p v-if="errors.weekdays" class="field-error">{{ errors.weekdays }}</p>
        <p class="field-help">{{ t('request.recurringHelp', { weeks: LIMITS.recurringMaxWeeks }) }}</p>
      </fieldset>
    </template>

    <div class="grid grid-cols-2 gap-3">
      <UiDateField v-model="form.startTime" type="time" :label="t('request.startTime')" :error="errors.startTime" step="900" required />
      <UiDateField v-model="form.endTime" type="time" :label="t('request.endTime')" :error="errors.endTime" step="900" required />
    </div>
    <p v-if="overnight && form.startTime !== form.endTime" class="-mt-2 text-sm text-muted">{{ t('request.overnight') }}</p>

    <UiCombobox v-model="form.locationId" :label="t('request.location')" :options="locationOptions" :error="errors.locationId" :placeholder="t('request.locationPlaceholder')" />
    <UiInput v-model="form.addressNote" :label="t('request.addressNote')" :help="t('request.addressHelp')" maxlength="300" />
    <UiTextarea v-model="form.requirements" :label="t('request.requirements')" :help="t('request.requirementsHelp')" :maxlength="LIMITS.requirementsMax" :rows="3" :error="errors.requirements" />

    <div class="flex gap-2 rounded-[var(--radius-control)] bg-primary-soft p-3 text-sm text-[#22433d]">
      <Info class="mt-0.5 size-4 shrink-0" aria-hidden="true" />
      <p>{{ t('request.notice') }}</p>
    </div>
    <p v-if="formError" class="field-error" role="alert">{{ formError }}</p>
    <UiButton type="submit" block size="lg" :loading="busy">{{ auth.user ? t('request.submit') : t('request.signInToSubmit') }}</UiButton>
  </form>
</template>
