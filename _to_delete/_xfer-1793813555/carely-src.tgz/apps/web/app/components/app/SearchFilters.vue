<script setup lang="ts">
import { ATTRIBUTE_GROUPS, PRICE_UNITS, SPOKEN_LANGUAGES, utcToZonedDate, type QualificationKind } from '@carely/shared';
import type { Filters } from '~/composables/useSearchFilters';
import { QUALIFICATIONS_BY_CATEGORY } from '~/composables/useSearchFilters';

/** Filters only offer options backed by the data model and API. Category-specific facets appear once a category is chosen. */
const model = defineModel<Filters>({ required: true });
const emit = defineEmits<{ commit: [] }>();
const props = defineProps<{ live?: boolean }>();
const { t } = useI18n();
const { categories, categoryBySlug } = useTaxonomy();
const { tx } = useFormat();
const locationOptions = useLocationOptions();

const cat = computed(() => categoryBySlug(model.value.category));
const groups = computed(() =>
  ATTRIBUTE_GROUPS.map((g) => ({ group: g, items: (cat.value?.attributes ?? []).filter((a) => a.group === g) })).filter((g) => g.items.length),
);
const quals = computed<QualificationKind[]>(() => (model.value.category ? QUALIFICATIONS_BY_CATEGORY[model.value.category] : undefined) ?? ['IDENTITY']);
const today = utcToZonedDate(new Date());

function patch(p: Partial<Filters>) {
  model.value = { ...model.value, ...p, page: 1 };
  if (props.live) emit('commit');
}
function setCategory(slug?: string) {
  // Category-specific facets are cleared when the category changes.
  patch({ category: slug, service: undefined, attributes: [], verified: model.value.verified.filter((v) => v === 'IDENTITY') });
}
const priceMin = ref(model.value.priceMin);
const priceMax = ref(model.value.priceMax);
watch(() => [model.value.priceMin, model.value.priceMax], ([a, b]) => ((priceMin.value = a), (priceMax.value = b)));
function commitPrice() {
  patch({ priceMin: priceMin.value || undefined, priceMax: priceMax.value || undefined, priceUnit: model.value.priceUnit ?? 'HOUR' });
}
function toggle(key: 'languages' | 'attributes' | 'verified', value: string, on: boolean) {
  const cur = new Set(model.value[key] as string[]);
  on ? cur.add(value) : cur.delete(value);
  patch({ [key]: [...cur] } as Partial<Filters>);
}
</script>

<template>
  <div class="space-y-6">
    <fieldset>
      <legend class="field-label">{{ t('filters.category') }}</legend>
      <div class="space-y-1">
        <label class="flex min-h-10 cursor-pointer items-center gap-3">
          <input type="radio" name="category" class="size-4 accent-primary" :checked="!model.category" @change="setCategory(undefined)" />
          <span>{{ t('filters.allCategories') }}</span>
        </label>
        <label v-for="c in categories ?? []" :key="c.id" class="flex min-h-10 cursor-pointer items-center gap-3">
          <input type="radio" name="category" class="size-4 accent-primary" :checked="model.category === c.slug" @change="setCategory(c.slug)" />
          <span>{{ tx(c.name) }}</span>
        </label>
      </div>
    </fieldset>

    <UiSelect
      v-if="cat"
      :model-value="model.service"
      :label="t('filters.service')"
      :placeholder="t('filters.anyService')"
      :options="cat.services.map((s) => ({ value: s.slug, label: tx(s.name) }))"
      @update:model-value="(v) => patch({ service: (v as string) || undefined })"
    />

    <UiCombobox
      :model-value="model.location"
      :label="t('filters.location')"
      :placeholder="t('search.anyLocation')"
      :options="locationOptions"
      :help="t('filters.locationHelp')"
      clearable
      @update:model-value="(v) => patch({ location: v })"
    />

    <UiDateField :model-value="model.date" :label="t('filters.date')" :min="today" :help="t('filters.dateHelp')" @update:model-value="(v) => patch({ date: v || undefined })" />

    <fieldset>
      <legend class="field-label">{{ t('filters.price') }}</legend>
      <UiSelect
        :model-value="model.priceUnit ?? 'HOUR'"
        :label="t('filters.priceUnit')"
        :options="PRICE_UNITS.map((u) => ({ value: u, label: t(`priceUnitLong.${u}`) }))"
        class="[&_.field-label]:sr-only"
        @update:model-value="(v) => patch({ priceUnit: v as any })"
      />
      <div class="mt-2 grid grid-cols-2 gap-2">
        <UiInput v-model.number="priceMin" type="number" inputmode="numeric" min="0" step="500" :label="t('filters.priceMin')" :placeholder="'0'" @blur="commitPrice" @keydown.enter.prevent="commitPrice" />
        <UiInput v-model.number="priceMax" type="number" inputmode="numeric" min="0" step="500" :label="t('filters.priceMax')" :placeholder="'—'" @blur="commitPrice" @keydown.enter.prevent="commitPrice" />
      </div>
      <p class="field-help">{{ t('filters.priceHelp') }}</p>
    </fieldset>

    <UiSelect
      :model-value="model.experienceMin ?? ''"
      :label="t('filters.experience')"
      :options="[
        { value: '', label: t('filters.anyExperience') },
        ...[1, 3, 5, 10].map((n) => ({ value: n, label: t('filters.experienceMin', n) })),
      ]"
      @update:model-value="(v) => patch({ experienceMin: v ? Number(v) : undefined })"
    />

    <fieldset v-for="g in groups" :key="g.group">
      <legend class="field-label">{{ t(`attributeGroup.${g.group}`) }}</legend>
      <UiCheckbox
        v-for="a in g.items"
        :key="a.id"
        :label="tx(a.name)"
        :model-value="model.attributes.includes(a.slug)"
        @update:model-value="(v) => toggle('attributes', a.slug, !!v)"
      />
    </fieldset>

    <fieldset>
      <legend class="field-label">{{ t('filters.verified') }}</legend>
      <UiCheckbox
        v-for="q in quals"
        :key="q"
        :label="t(`verification.kind.${q}`)"
        :model-value="model.verified.includes(q)"
        @update:model-value="(v) => toggle('verified', q, !!v)"
      />
    </fieldset>

    <fieldset>
      <legend class="field-label">{{ t('filters.languages') }}</legend>
      <div class="grid grid-cols-2 gap-x-2">
        <UiCheckbox
          v-for="l in SPOKEN_LANGUAGES.slice(0, 6)"
          :key="l"
          :label="t(`lang.${l}`)"
          :model-value="model.languages.includes(l)"
          @update:model-value="(v) => toggle('languages', l, !!v)"
        />
      </div>
    </fieldset>
  </div>
</template>
