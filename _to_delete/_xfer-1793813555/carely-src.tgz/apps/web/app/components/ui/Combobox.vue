<script setup lang="ts">
import { Check, ChevronDown, X } from 'lucide-vue-next';
/** Accessible searchable single-select (WAI-ARIA combobox with listbox popup). */
const model = defineModel<string | undefined>();
const props = defineProps<{
  label?: string;
  placeholder?: string;
  error?: string;
  help?: string;
  options: { value: string; label: string; hint?: string; indent?: boolean }[];
  clearable?: boolean;
  hideLabel?: boolean;
}>();
const { t } = useI18n();
const id = useId();
const listId = `${id}-list`;
const query = ref('');
const open = ref(false);
const active = ref(0);
const input = ref<HTMLInputElement | null>(null);

const selected = computed(() => props.options.find((o) => o.value === model.value));
const norm = (s: string) => s.toLocaleLowerCase().normalize('NFKD');
const filtered = computed(() => {
  const q = norm(query.value.trim());
  if (!q) return props.options;
  return props.options.filter((o) => norm(o.label).includes(q) || norm(o.hint ?? '').includes(q));
});
watch(selected, (s) => {
  if (!open.value) query.value = s?.label ?? '';
}, { immediate: true });

function openList() {
  open.value = true;
  query.value = '';
  active.value = Math.max(0, filtered.value.findIndex((o) => o.value === model.value));
}
function choose(v: string) {
  model.value = v;
  open.value = false;
  query.value = props.options.find((o) => o.value === v)?.label ?? '';
}
function close() {
  open.value = false;
  query.value = selected.value?.label ?? '';
}
function onKey(e: KeyboardEvent) {
  if (!open.value && (e.key === 'ArrowDown' || e.key === 'Enter')) {
    openList();
    e.preventDefault();
    return;
  }
  if (e.key === 'ArrowDown') active.value = Math.min(filtered.value.length - 1, active.value + 1);
  else if (e.key === 'ArrowUp') active.value = Math.max(0, active.value - 1);
  else if (e.key === 'Enter') {
    const o = filtered.value[active.value];
    if (o) choose(o.value);
  } else if (e.key === 'Escape') close();
  else return;
  e.preventDefault();
  nextTick(() => document.getElementById(`${id}-opt-${active.value}`)?.scrollIntoView({ block: 'nearest' }));
}
function clear() {
  model.value = undefined;
  query.value = '';
  input.value?.focus();
}
</script>

<template>
  <UiField :id="id" :label="label" :error="error" :help="help">
    <div class="relative" @focusout="(e: FocusEvent) => !(e.currentTarget as HTMLElement).contains(e.relatedTarget as Node) && close()">
      <input
        :id="id"
        ref="input"
        v-model="query"
        role="combobox"
        :aria-label="hideLabel ? label : undefined"
        :aria-expanded="open"
        :aria-controls="listId"
        aria-autocomplete="list"
        :aria-activedescendant="open && filtered.length ? `${id}-opt-${active}` : undefined"
        :placeholder="placeholder"
        autocomplete="off"
        class="control pr-16"
        :aria-invalid="!!error || undefined"
        @focus="openList"
        @click="!open && openList()"
        @input="open = true; active = 0"
        @keydown="onKey"
      />
      <div class="absolute right-2 top-1/2 flex -translate-y-1/2 items-center gap-1 text-muted">
        <button v-if="clearable && model" type="button" class="rounded p-1 hover:bg-bg" :aria-label="t('common.clear')" @click="clear"><X class="size-4" /></button>
        <ChevronDown class="size-4" aria-hidden="true" />
      </div>
      <ul
        v-show="open"
        :id="listId"
        role="listbox"
        tabindex="-1"
        class="absolute z-30 mt-1 max-h-72 w-full overflow-auto rounded-[var(--radius-control)] border border-line bg-surface py-1 shadow-[var(--shadow-pop)]"
      >
        <li v-if="!filtered.length" class="px-3 py-2 text-sm text-muted">{{ t('common.noMatches') }}</li>
        <li
          v-for="(o, i) in filtered"
          :id="`${id}-opt-${i}`"
          :key="o.value"
          role="option"
          :aria-selected="o.value === model"
          class="flex cursor-pointer items-center justify-between gap-2 px-3 py-2 text-[0.9375rem]"
          :class="[i === active ? 'bg-primary-soft' : '', o.indent ? 'pl-7' : 'font-medium']"
          @mousedown.prevent="choose(o.value)"
          @mousemove="active = i"
        >
          <span>
            {{ o.label }}
            <span v-if="o.hint" class="ml-1 text-sm font-normal text-muted">{{ o.hint }}</span>
          </span>
          <Check v-if="o.value === model" class="size-4 text-primary" aria-hidden="true" />
        </li>
      </ul>
    </div>
  </UiField>
</template>
