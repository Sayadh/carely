import type { LocationDto } from '@carely/shared';

/** Combobox options: each region followed by its towns/districts (indented). Optionally restricted to a set of ids. */
export function useLocationOptions(restrictTo?: Ref<string[] | null | undefined>, valueKey: 'slug' | 'id' = 'slug') {
  const { locations } = useTaxonomy();
  const { tx } = useFormat();
  return computed(() => {
    const all = locations.value ?? [];
    const allowed = restrictTo?.value ? expand(all, restrictTo.value) : null;
    const out: { value: string; label: string; hint?: string; indent?: boolean }[] = [];
    for (const r of all.filter((l) => l.type === 'REGION')) {
      const kids = all.filter((l) => l.parentId === r.id && (!allowed || allowed.has(l.id)));
      if (allowed && !allowed.has(r.id) && !kids.length) continue;
      if (!allowed || allowed.has(r.id)) out.push({ value: r[valueKey], label: tx(r.name) });
      else out.push({ value: r[valueKey], label: tx(r.name) });
      for (const k of kids) out.push({ value: k[valueKey], label: tx(k.name), hint: tx(r.name), indent: true });
    }
    return allowed ? out.filter((o) => allowed.has(all.find((l) => l[valueKey] === o.value)!.id)) : out;
  });
}

/** A service area also covers everything inside it. */
function expand(all: LocationDto[], ids: string[]) {
  const set = new Set(ids);
  let grew = true;
  while (grew) {
    grew = false;
    for (const l of all) if (l.parentId && set.has(l.parentId) && !set.has(l.id)) (set.add(l.id), (grew = true));
  }
  return set;
}
