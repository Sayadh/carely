import type { LocationQuery } from 'vue-router';
import type { PriceUnit, QualificationKind, SearchSort } from '@carely/shared';

export interface Filters {
  category?: string;
  service?: string;
  location?: string;
  priceUnit?: PriceUnit;
  priceMin?: number;
  priceMax?: number;
  experienceMin?: number;
  languages: string[];
  attributes: string[];
  verified: QualificationKind[];
  date?: string;
  sort: SearchSort;
  page: number;
}

const list = (v: unknown) => (typeof v === 'string' && v ? v.split(',') : Array.isArray(v) ? (v as string[]) : []);
const num = (v: unknown) => (typeof v === 'string' && v !== '' && !isNaN(Number(v)) ? Number(v) : undefined);
const str = (v: unknown) => (typeof v === 'string' && v ? v : undefined);

export function parseFilters(q: LocationQuery): Filters {
  return {
    category: str(q.category),
    service: str(q.service),
    location: str(q.location),
    priceUnit: str(q.priceUnit) as PriceUnit | undefined,
    priceMin: num(q.priceMin),
    priceMax: num(q.priceMax),
    experienceMin: num(q.experienceMin),
    languages: list(q.languages),
    attributes: list(q.attributes),
    verified: list(q.verified) as QualificationKind[],
    date: str(q.date),
    sort: (str(q.sort) as SearchSort) ?? 'relevance',
    page: num(q.page) ?? 1,
  };
}

/** Shareable URL query; empty values are omitted. */
export function toQuery(f: Partial<Filters>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(f)) {
    if (v === undefined || v === null || v === '') continue;
    if (Array.isArray(v)) {
      if (v.length) out[k] = v.join(',');
    } else if (k === 'sort' && v === 'relevance') continue;
    else if (k === 'page' && v === 1) continue;
    else out[k] = String(v);
  }
  return out;
}

/** Credentials that are meaningful filters for each category. */
export const QUALIFICATIONS_BY_CATEGORY: Record<string, QualificationKind[]> = {
  childcare: ['IDENTITY', 'PEDAGOGY', 'FIRST_AID'],
  'elderly-care': ['IDENTITY', 'FIRST_AID', 'MEDICAL_EDUCATION'],
  'patient-care': ['IDENTITY', 'NURSING_LICENSE', 'MEDICAL_EDUCATION', 'FIRST_AID'],
  'pet-care': ['IDENTITY', 'VETERINARY'],
};

export function activeFilterCount(f: Filters) {
  return (
    (f.service ? 1 : 0) +
    (f.priceMin != null || f.priceMax != null ? 1 : 0) +
    (f.experienceMin ? 1 : 0) +
    f.languages.length +
    f.attributes.length +
    f.verified.length +
    (f.date ? 1 : 0)
  );
}
