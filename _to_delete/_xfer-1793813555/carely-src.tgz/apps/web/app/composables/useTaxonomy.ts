import type { CategoryDto, LocationDto } from '@carely/shared';

/** Categories, services, facets and locations (cached in the SSR payload). */
export function useTaxonomy() {
  const api = useApi();
  const categories = useState<CategoryDto[] | null>('tx:categories', () => null);
  const locations = useState<LocationDto[] | null>('tx:locations', () => null);

  async function load() {
    if (categories.value && locations.value) return;
    const [c, l] = await Promise.all([api<CategoryDto[]>('/taxonomy/categories'), api<LocationDto[]>('/taxonomy/locations')]);
    categories.value = c;
    locations.value = l;
  }

  const regions = computed(() => (locations.value ?? []).filter((l) => l.type === 'REGION'));
  const childrenOf = (id: string) => (locations.value ?? []).filter((l) => l.parentId === id);
  const locationBySlug = (slug?: string | null) => (locations.value ?? []).find((l) => l.slug === slug);
  const locationById = (id?: string | null) => (locations.value ?? []).find((l) => l.id === id);
  const categoryBySlug = (slug?: string | null) => (categories.value ?? []).find((c) => c.slug === slug);
  const categoryById = (id?: string | null) => (categories.value ?? []).find((c) => c.id === id);
  const allServices = computed(() => (categories.value ?? []).flatMap((c) => c.services));

  return { categories, locations, load, regions, childrenOf, locationBySlug, locationById, categoryBySlug, categoryById, allServices };
}
