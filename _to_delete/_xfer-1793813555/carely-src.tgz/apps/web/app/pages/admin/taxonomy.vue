<script setup lang="ts">
import { Plus, Pencil, Trash2 } from 'lucide-vue-next';
import { ATTRIBUTE_GROUPS, QUALIFICATION_KINDS } from '@carely/shared';
definePageMeta({ layout: 'admin', middleware: 'admin' });
const { t, locale } = useI18n();
const api = useApi();
const toast = useToast();
const errMsg = useErrorMessage();
useSeoMeta({ title: () => t('admin.nav.taxonomy'), robots: 'noindex' });
const { data, refresh } = await useAsyncData('admin:taxonomy', () => api<any[]>('/admin/taxonomy'));
const label = (tr: any[]) => tr.find((x) => x.locale === locale.value)?.name ?? tr.find((x) => x.locale === 'hy')?.name ?? '—';
const usage = (c: any) => Object.values(c._count ?? {}).reduce((a: number, b: any) => a + Number(b), 0) as number;

type Kind = 'categories' | 'services' | 'attributes';
const editing = ref<null | { kind: Kind; id?: string; form: any }>(null);
const blankTx = () => ({ hy: { name: '', description: '' }, ru: { name: '', description: '' }, en: { name: '', description: '' } });
function txFrom(rows: any[]) {
  const out: any = blankTx();
  for (const r of rows) out[r.locale] = { name: r.name, description: r.description ?? '' };
  return out;
}
function open(kind: Kind, row?: any, categoryId?: string) {
  editing.value = {
    kind,
    id: row?.id,
    form: {
      slug: row?.slug ?? '',
      sortOrder: row?.sortOrder ?? 0,
      active: row?.active ?? true,
      categoryId: row?.categoryId ?? categoryId,
      group: row?.group ?? 'TASK',
      requiredQualification: row?.requiredQualification ?? null,
      translations: row ? txFrom(row.translations) : blankTx(),
    },
  };
}
async function save() {
  const e = editing.value!;
  const body: any = { slug: e.form.slug, sortOrder: Number(e.form.sortOrder) || 0, active: e.form.active, translations: e.form.translations };
  if (e.kind !== 'categories') body.categoryId = e.form.categoryId;
  if (e.kind === 'services') body.requiredQualification = e.form.requiredQualification || null;
  if (e.kind === 'attributes') body.group = e.form.group;
  try {
    await api(`/admin/${e.kind}${e.id ? `/${e.id}` : ''}`, { method: e.id ? 'PUT' : 'POST', body });
    toast.success(t('admin.saved'));
    editing.value = null;
    refresh();
  } catch (err) {
    toast.error(errMsg(err));
  }
}
async function remove(kind: Kind, id: string) {
  try {
    await api(`/admin/${kind}/${id}`, { method: 'DELETE' });
    toast.success(t('admin.saved'));
    refresh();
  } catch (err) {
    toast.error(errMsg(err));
  }
}
</script>

<template>
  <div>
    <AppPageHeader :title="t('admin.nav.taxonomy')" :subtitle="t('admin.taxonomySubtitle')">
      <UiButton variant="secondary" @click="open('categories')"><Plus class="size-4" aria-hidden="true" />{{ t('admin.addCategory') }}</UiButton>
    </AppPageHeader>
    <div class="space-y-6">
      <UiCard v-for="c in data ?? []" :key="c.id">
        <div class="flex flex-wrap items-center justify-between gap-2">
          <div class="flex items-center gap-2">
            <h2 class="text-lg font-semibold">{{ label(c.translations) }}</h2>
            <code class="text-xs text-muted">{{ c.slug }}</code>
            <AppAdminCompleteness :translations="c.translations" />
            <UiBadge v-if="!c.active" tone="neutral">{{ t('admin.inactive') }}</UiBadge>
          </div>
          <div class="flex gap-1">
            <UiButton size="sm" variant="ghost" @click="open('categories', c)"><Pencil class="size-4" aria-hidden="true" />{{ t('common.edit') }}</UiButton>
          </div>
        </div>
        <div class="mt-4 grid gap-6 lg:grid-cols-2">
          <section>
            <div class="flex items-center justify-between"><h3 class="font-medium">{{ t('admin.services') }}</h3><UiButton size="sm" variant="ghost" @click="open('services', undefined, c.id)"><Plus class="size-4" aria-hidden="true" />{{ t('common.add') }}</UiButton></div>
            <ul class="mt-2 divide-y divide-line rounded-[var(--radius-control)] border border-line">
              <li v-for="s in c.services" :key="s.id" class="flex flex-wrap items-center gap-2 px-3 py-2 text-[0.9375rem]">
                <span class="flex-1">{{ label(s.translations) }} <UiBadge v-if="s.requiredQualification" tone="warning">{{ t(`verification.kind.${s.requiredQualification}`) }}</UiBadge> <UiBadge v-if="!s.active">{{ t('admin.inactive') }}</UiBadge></span>
                <AppAdminCompleteness :translations="s.translations" />
                <span class="text-xs text-muted">{{ t('admin.usedBy', { n: usage(s) }) }}</span>
                <button type="button" class="rounded p-1.5 text-muted hover:bg-bg" :aria-label="t('common.edit')" @click="open('services', s)"><Pencil class="size-4" /></button>
                <button v-if="!usage(s)" type="button" class="rounded p-1.5 text-muted hover:bg-bg hover:text-danger" :aria-label="t('common.delete')" @click="remove('services', s.id)"><Trash2 class="size-4" /></button>
              </li>
            </ul>
          </section>
          <section>
            <div class="flex items-center justify-between"><h3 class="font-medium">{{ t('admin.attributes') }}</h3><UiButton size="sm" variant="ghost" @click="open('attributes', undefined, c.id)"><Plus class="size-4" aria-hidden="true" />{{ t('common.add') }}</UiButton></div>
            <ul class="mt-2 divide-y divide-line rounded-[var(--radius-control)] border border-line">
              <li v-for="a in c.attributes" :key="a.id" class="flex flex-wrap items-center gap-2 px-3 py-2 text-[0.9375rem]">
                <span class="flex-1">{{ label(a.translations) }} <span class="text-xs text-muted">· {{ t(`attributeGroup.${a.group}`) }}</span></span>
                <AppAdminCompleteness :translations="a.translations" />
                <button type="button" class="rounded p-1.5 text-muted hover:bg-bg" :aria-label="t('common.edit')" @click="open('attributes', a)"><Pencil class="size-4" /></button>
                <button v-if="!usage(a)" type="button" class="rounded p-1.5 text-muted hover:bg-bg hover:text-danger" :aria-label="t('common.delete')" @click="remove('attributes', a.id)"><Trash2 class="size-4" /></button>
              </li>
            </ul>
          </section>
        </div>
      </UiCard>
    </div>
    <UiDialog :open="!!editing" :title="editing?.id ? t('common.edit') : t('common.add')" @update:open="(v) => !v && (editing = null)">
      <form v-if="editing" id="tx-form" class="space-y-4" @submit.prevent="save">
        <div class="grid gap-3 sm:grid-cols-3">
          <UiInput v-model="editing.form.slug" :label="t('admin.tx.slug')" :help="t('admin.tx.slugHelp')" required class="sm:col-span-2" />
          <UiInput v-model.number="editing.form.sortOrder" type="number" :label="t('admin.tx.order')" />
        </div>
        <UiSelect v-if="editing.kind === 'attributes'" v-model="editing.form.group" :label="t('admin.tx.group')" :options="ATTRIBUTE_GROUPS.map((g) => ({ value: g, label: t(`attributeGroup.${g}`) }))" />
        <UiSelect v-if="editing.kind === 'services'" v-model="editing.form.requiredQualification" :label="t('admin.tx.requiredQualification')" :placeholder="t('admin.tx.none')" :options="QUALIFICATION_KINDS.map((k) => ({ value: k, label: t(`verification.kind.${k}`) }))" />
        <UiCheckbox v-model="editing.form.active" :label="t('admin.tx.active')" :hint="t('admin.tx.activeHelp')" />
        <AppAdminTranslationFields v-model="editing.form.translations" :with-description="editing.kind === 'categories'" />
      </form>
      <template #footer>
        <UiButton variant="ghost" @click="editing = null">{{ t('common.cancel') }}</UiButton>
        <UiButton type="submit" form="tx-form">{{ t('common.save') }}</UiButton>
      </template>
    </UiDialog>
  </div>
</template>
