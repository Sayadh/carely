<script setup lang="ts">
import { ClipboardList, CalendarDays, ArrowRight } from 'lucide-vue-next';
import type { Paginated, RequestSummaryDto } from '@carely/shared';
definePageMeta({ layout: 'dashboard', section: 'pro', middleware: 'auth' });
const { t } = useI18n();
const api = useApi();
const localePath = useLocalePath();
const { profile, load } = useProProfile();
const { range, tx } = useFormat();
await load();
if (!profile.value) await navigateTo(localePath('/become-a-professional'));
useSeoMeta({ title: () => t('nav.proDashboard'), robots: 'noindex' });

const { data: incoming } = await useAsyncData('pro:incoming', () => api<Paginated<RequestSummaryDto>>('/requests', { query: { as: 'professional', status: 'SUBMITTED' } }));
const { data: schedule } = await useAsyncData('pro:schedule-preview', () =>
  api<{ startAt: string; endAt: string; requestId: string; service: any; location: any; customerName: string }[]>('/requests/schedule'),
);
const upcoming = computed(() => (schedule.value ?? []).filter((s) => new Date(s.endAt) > new Date()).slice(0, 5));
const statusTone = computed(() => ({ DRAFT: 'neutral', PENDING: 'warning', APPROVED: 'success', REJECTED: 'danger', SUSPENDED: 'danger' })[profile.value?.status ?? 'DRAFT'] as any);
const missing = computed(() => (profile.value ? Object.entries(profile.value.completeness).filter(([, ok]) => !ok).length : 0));
</script>

<template>
  <div v-if="profile" class="space-y-6">
    <AppPageHeader :title="t('nav.proDashboard')">
      <UiButton v-if="profile.status === 'APPROVED'" variant="secondary" :to="localePath(`/professionals/${profile.slug}`)">{{ t('onboarding.viewPublic') }}</UiButton>
    </AppPageHeader>

    <UiCard>
      <div class="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p class="text-sm text-muted">{{ t('pro.profileStatus') }}</p>
          <div class="mt-1 flex items-center gap-2"><UiBadge :tone="statusTone">{{ t(`profileStatus.${profile.status}`) }}</UiBadge></div>
          <p class="mt-3 max-w-xl text-[#475467]">{{ t(`pro.statusText.${profile.status}`) }}</p>
          <p v-if="profile.status === 'REJECTED' && profile.rejectionReason" class="mt-2 text-danger">{{ t('onboarding.rejectedTitle') }}: {{ profile.rejectionReason }}</p>
        </div>
        <UiButton v-if="profile.status === 'DRAFT' || profile.status === 'REJECTED'" :to="localePath('/pro/onboarding')">
          {{ missing ? t('pro.continueOnboarding') : t('onboarding.submit') }} <ArrowRight class="size-4" aria-hidden="true" />
        </UiButton>
      </div>
    </UiCard>

    <div class="grid gap-6 lg:grid-cols-2">
      <UiCard>
        <div class="flex items-center justify-between">
          <h2 class="flex items-center gap-2 text-lg font-semibold"><ClipboardList class="size-5 text-muted" aria-hidden="true" />{{ t('pro.newRequests') }}</h2>
          <NuxtLink :to="localePath('/pro/requests')" class="text-sm font-medium text-primary hover:underline">{{ t('common.viewAll') }}</NuxtLink>
        </div>
        <ul v-if="incoming?.items.length" class="mt-4 space-y-3"><AppRequestRow v-for="r in incoming.items.slice(0, 4)" :key="r.id" :r="r" /></ul>
        <p v-else class="mt-4 text-muted">{{ t('pro.noNewRequests') }}</p>
      </UiCard>
      <UiCard>
        <div class="flex items-center justify-between">
          <h2 class="flex items-center gap-2 text-lg font-semibold"><CalendarDays class="size-5 text-muted" aria-hidden="true" />{{ t('pro.upcoming') }}</h2>
          <NuxtLink :to="localePath('/pro/schedule')" class="text-sm font-medium text-primary hover:underline">{{ t('common.viewAll') }}</NuxtLink>
        </div>
        <ul v-if="upcoming.length" class="mt-4 divide-y divide-line">
          <li v-for="s in upcoming" :key="s.startAt + s.requestId">
            <NuxtLink :to="localePath(`/requests/${s.requestId}`)" class="block py-3 hover:text-primary">
              <p class="font-medium">{{ range(s.startAt, s.endAt) }}</p>
              <p class="text-sm text-muted">{{ tx(s.service) }} · {{ s.customerName }} · {{ tx(s.location) }}</p>
            </NuxtLink>
          </li>
        </ul>
        <p v-else class="mt-4 text-muted">{{ t('pro.noUpcoming') }}</p>
      </UiCard>
    </div>
  </div>
</template>
