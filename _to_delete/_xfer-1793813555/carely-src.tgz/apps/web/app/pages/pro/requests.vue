<script setup lang="ts">
definePageMeta({ layout: 'dashboard', section: 'pro', middleware: 'auth' });
const { t } = useI18n();
useSeoMeta({ title: () => t('pro.nav.requests'), robots: 'noindex' });
</script>

<template>
  <div>
    <AppPageHeader :title="t('pro.nav.requests')" :subtitle="t('pro.requestsSubtitle')" />
    <AppRequestList as="professional" />
  </div>
</template>
