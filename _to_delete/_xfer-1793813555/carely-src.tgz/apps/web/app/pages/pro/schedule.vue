<script setup lang="ts">
import { CalendarDays } from 'lucide-vue-next';
import { utcToZonedDate } from '@carely/shared';
definePageMeta({ layout: 'dashboard', section: 'pro', middleware: 'auth' });
const { t } = useI18n();
const api = useApi();
const localePath = useLocalePath();
const { time, tx, ymd } = useFormat();
useSeoMeta({ title: () => t('pro.nav.schedule'), robots: 'noindex' });
const { data } = await useAsyncData('pro:schedule', () =>
  api<{ startAt: string; endAt: string; requestId: string; status: string; service: any; location: any; customerName: string }[]>('/requests/schedule'),
);
const groups = computed(() => {
  const map = new Map<string, NonNullable<typeof data.value>>();
  for (const s of data.value ?? []) {
    const d = utcToZonedDate(new Date(s.startAt));
    if (!map.has(d)) map.set(d, []);
    map.get(d)!.push(s);
  }
  return [...map.entries()];
});
const today = utcToZonedDate(new Date());
</script>

<template>
  <div class="max-w-3xl">
    <AppPageHeader :title="t('pro.nav.schedule')" :subtitle="t('pro.scheduleSubtitle')" />
    <UiEmptyState v-if="!groups.length" :icon="CalendarDays" :title="t('pro.noUpcoming')" :text="t('pro.scheduleEmptyText')" />
    <div v-else class="space-y-5">
      <section v-for="[day, items] in groups" :key="day" :aria-label="ymd(day, { weekday: 'long', day: 'numeric', month: 'long' })">
        <h2 class="mb-2 text-sm font-semibold" :class="day < today ? 'text-subtle' : 'text-muted'">
          {{ ymd(day, { weekday: 'long', day: 'numeric', month: 'long' }) }}<span v-if="day === today"> · {{ t('common.today') }}</span>
        </h2>
        <ul class="space-y-2">
          <li v-for="s in items" :key="s.startAt + s.requestId">
            <NuxtLink :to="localePath(`/requests/${s.requestId}`)" class="card flex items-center gap-4 p-4 hover:shadow-[var(--shadow-card)]" :class="day < today ? 'opacity-70' : ''">
              <p class="w-28 shrink-0 font-semibold">{{ time(s.startAt) }}–{{ time(s.endAt) }}</p>
              <div class="min-w-0">
                <p class="font-medium">{{ tx(s.service) }}</p>
                <p class="text-sm text-muted">{{ s.customerName }} · {{ tx(s.location) }}</p>
              </div>
              <AppStatusBadge :status="s.status as any" class="ml-auto" />
            </NuxtLink>
          </li>
        </ul>
      </section>
    </div>
  </div>
</template>
