/**
 * Same-origin proxy to the NestJS API. Cookies stay first-party (no CORS),
 * and SSR requests reach the API through the same path with forwarded cookies.
 */
export default defineEventHandler(async (event) => {
  const { apiInternalUrl } = useRuntimeConfig(event);
  const target = apiInternalUrl.replace(/\/$/, '') + event.path;
  const ip = getRequestIP(event, { xForwardedFor: true });
  return proxyRequest(event, target, {
    headers: ip ? { 'x-forwarded-for': ip } : {},
  });
});
