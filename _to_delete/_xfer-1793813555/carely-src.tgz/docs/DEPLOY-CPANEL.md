# Deployment — cPanel shared hosting (target)

> **Status: blocked on host verification.** Nothing here has been run against the purchased plan. The plan is 3 GB SSD **disk** with MySQL/MariaDB; Node.js support, memory/process limits and application-manager features are unconfirmed. SSH access alone does not prove persistent Node.js apps are allowed. Do not switch to PHP or a static build if Node is unavailable — the app needs two Node processes (Nuxt SSR + NestJS).

## 1. Capabilities to confirm with the host (checklist)

| # | Check | How | Needed |
|---|---|---|---|
| 1 | DB engine and exact version | cPanel → MySQL Databases, or `mysql -V` / `SELECT VERSION();` | MySQL ≥ 8.0 or MariaDB ≥ 10.6 |
| 2 | DB privileges for the app user | `SHOW GRANTS;` | SELECT/INSERT/UPDATE/DELETE/CREATE/ALTER/INDEX/REFERENCES/DROP (for migrations), row locks; no shadow DB needed in prod |
| 3 | Node.js versions | cPanel → "Setup Node.js App" (CloudLinux selector) | Node 20.19+ or 22 |
| 4 | Two Node apps (or one app + internal routing) | Can you create 2 apps on one domain/subdomains? | `carely.am` → Nuxt, `api` reachable by Nuxt (subdomain or internal port) |
| 5 | Startup file / Passenger | Application manager fields | Nuxt: `apps/web/.output/server/index.mjs`; API: `apps/api/dist/main.js` (ESM vs CJS support in Passenger) |
| 6 | Environment variables | App manager env editor or `.env` support | yes |
| 7 | Memory / CPU / process (EP/NPROC) limits | Host docs / cPanel stats | ≥ 512 MB per app recommended; both apps must fit |
| 8 | Persistent processes vs idle shutdown | Ask host | Passenger idle-spawn is fine; jobs must not rely on in-process timers (they don't) |
| 9 | Cron jobs | cPanel → Cron Jobs | every 10 min for `jobs-cli.js` |
| 10 | Outbound SMTP / mailbox | cPanel email account | SMTP host/port/credentials |
| 11 | DB connection limits | Host policy (`max_user_connections`) | `connection_limit=5` per app process |
| 12 | Native modules | Can `sharp` prebuilt binaries load (glibc, x64/arm64)? | yes, or replace portrait resizing |
| 13 | Disk budget | What counts toward 3 GB (DB, mail, backups, logs)? | See §5 |

## 2. Build (locally or CI — not on the host)
```bash
npm ci
npm run build
```
Upload only runtime artefacts:
- `packages/shared/dist`, `packages/shared/package.json`
- `apps/api/dist`, `apps/api/prisma` (schema + migrations), `apps/api/package.json`
- `apps/web/.output` (self-contained Nitro server; no node_modules needed)
- root `package.json`, `package-lock.json`

On the host install production deps for the API only: `npm ci --omit=dev --workspace @carely/api --include-workspace-root` then `npx prisma generate` (from apps/api). Prisma CLI is a devDependency; for migrations either run `prisma migrate deploy` from CI against the production DB (if remote connections are allowed) or temporarily install the CLI on the host.

## 3. Database
1. Create DB + user in cPanel (utf8mb4 / utf8mb4_unicode_ci).
2. **Back up first**, then `npx prisma migrate deploy` (reviewed migrations only). Never `migrate dev` or `migrate reset` in production.
3. After migrations that touch ratings, run the jobs once (`node dist/jobs-cli.js` in apps/api) — it rebuilds stored professional ratings that are out of date.
4. `npm run db:seed` (reference data only). **Never** run the demo seed in production (it refuses unless `DEMO_MODE=true`).
5. Create the first admin manually (trusted server-side step), e.g. register normally, then `UPDATE User SET isAdmin=1 WHERE email='…';` via phpMyAdmin.

## 4. Applications (provisional — finalise after §1)
**API app:** root `apps/api`, startup `dist/main.js`, env from `apps/api/.env.example` with `NODE_ENV=production`, `COOKIE_SECURE=true`, `APP_ORIGIN=https://carely.am`, `MAIL_DRIVER=smtp`, `DEMO_MODE=false`, `JOBS_TOKEN` (≥32 chars), `STORAGE_DRIVER=s3` (recommended), `TRUST_PROXY` = number of proxies in front (Passenger/Apache usually 1, plus Nuxt proxy = 2).

**Web app:** root `apps/web`, startup `.output/server/index.mjs`, env `NUXT_API_INTERNAL_URL` (where the API listens/is reachable), `NUXT_PUBLIC_SITE_URL=https://carely.am`, `NUXT_PUBLIC_DEMO_MODE=false`.

Health checks: `GET /api/health` (API, checks DB). Restart via the application manager's "Restart" (or `touch tmp/restart.txt` under Passenger). Both apps handle SIGTERM gracefully (Nest shutdown hooks close Prisma).

**Cron:** `*/10 * * * * cd ~/carely/apps/api && /path/to/nodevenv/bin/node dist/jobs-cli.js >> ~/logs/carely-jobs.log 2>&1`

## 5. Storage budget (3 GB disk)
- Code + production deps ≈ 300–450 MB (Nuxt output ~6 MB; API deps incl. Prisma engines and sharp are the bulk).
- Portraits are resized to 720×720 WebP (~40–90 KB each). Documents up to 8 MB each, max 5 per credential.
- Put media in S3-compatible storage (`STORAGE_DRIVER=s3`, separate public/private buckets) so growth does not consume hosting disk.
- Rotate logs (cPanel logrotate or truncate in cron). Keep DB backups off-host.
- This plan has not been load-tested; do not assume it is sufficient for production traffic.

## 6. If Node apps are not supported
Deployment is blocked. Options: upgrade to a plan with Node.js app support, or use the VPS guide. The local implementation remains fully usable.
