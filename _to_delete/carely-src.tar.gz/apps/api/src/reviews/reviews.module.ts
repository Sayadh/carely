import { Controller, Injectable, Module, Post } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Prisma, ReviewStatus } from '@prisma/client';
import { z } from 'zod';
import { createReviewSchema } from '@carely/shared';
import { PrismaService } from '../common/prisma.service';
import { AppError } from '../common/app-error';
import { ApiZodBody, Auth, AuthUser, CurrentUser, RateLimit, ZBody } from '../common/http';
import { NotificationsService } from '../notifications/notifications.module';

@Injectable()
export class ReviewsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly notifications: NotificationsService,
  ) {}

  /** One review per COMPLETED request, by its customer only. Starts PENDING moderation. */
  async create(user: AuthUser, input: z.output<typeof createReviewSchema>) {
    const r = await this.prisma.careRequest.findUnique({ where: { id: input.requestId }, include: { professional: { select: { userId: true } }, review: true } });
    if (!r || r.customerId !== user.id) throw new AppError('REVIEW_NOT_ELIGIBLE');
    if (r.status !== 'COMPLETED') throw new AppError('REVIEW_NOT_ELIGIBLE');
    if (r.professional.userId === user.id) throw new AppError('REVIEW_NOT_ELIGIBLE');
    if (r.review) throw new AppError('REVIEW_EXISTS');
    try {
      const review = await this.prisma.review.create({
        data: { requestId: r.id, customerId: user.id, profileId: r.professionalId, rating: input.rating, body: input.body, locale: input.locale },
      });
      return { id: review.id, status: review.status };
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') throw new AppError('REVIEW_EXISTS');
      throw e;
    }
  }

  /**
   * Moderation keeps rating aggregates consistent: the aggregate changes only when a review enters or leaves PUBLISHED,
   * using a conditional status update inside the same transaction.
   */
  async moderate(reviewId: string, status: ReviewStatus, adminId: string, note: string, tx: Prisma.TransactionClient) {
    const review = await tx.review.findUnique({ where: { id: reviewId } });
    if (!review) throw new AppError('NOT_FOUND');
    if (review.status === status) return review;
    const res = await tx.review.updateMany({
      where: { id: reviewId, status: review.status },
      data: { status, moderatedAt: new Date(), moderatedBy: adminId, moderationNote: note || null },
    });
    if (res.count !== 1) throw new AppError('CONFLICT');
    if (status === 'PUBLISHED') {
      await tx.professionalProfile.update({ where: { id: review.profileId }, data: { ratingCount: { increment: 1 }, ratingSum: { increment: review.rating } } });
    } else if (review.status === 'PUBLISHED') {
      await tx.professionalProfile.update({ where: { id: review.profileId }, data: { ratingCount: { decrement: 1 }, ratingSum: { decrement: review.rating } } });
    }
    await this.notifications.notify(review.customerId, status === 'PUBLISHED' ? 'REVIEW_PUBLISHED' : 'REVIEW_REJECTED', { reviewId }, tx);
    return review;
  }
}

@ApiTags('reviews')
@Controller('reviews')
export class ReviewsController {
  constructor(private readonly service: ReviewsService) {}

  @Post()
  @Auth()
  @RateLimit('review', 20, 3600)
  @ApiZodBody(createReviewSchema)
  create(@CurrentUser() u: AuthUser, @ZBody(createReviewSchema) b: z.output<typeof createReviewSchema>) {
    return this.service.create(u, b);
  }
}

@Module({ controllers: [ReviewsController], providers: [ReviewsService], exports: [ReviewsService] })
export class ReviewsModule {}
