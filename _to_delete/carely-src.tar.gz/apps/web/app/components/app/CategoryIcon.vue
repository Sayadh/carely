<script setup lang="ts">
import { Baby, HeartHandshake, Stethoscope, PawPrint, HandHeart } from 'lucide-vue-next';
const props = defineProps<{ slug: string }>();
const icon = computed(() => ({ childcare: Baby, 'elderly-care': HeartHandshake, 'patient-care': Stethoscope, 'pet-care': PawPrint })[props.slug] ?? HandHeart);
</script>

<template>
  <component :is="icon" aria-hidden="true" />
</template>
