<script setup lang="ts">
import { ArrowRight, ClipboardCheck, Search, MessageCircleReply, ShieldCheck, BadgeCheck, FileSearch } from 'lucide-vue-next';
import type { ProfessionalCardDto } from '@carely/shared';

const { t, tm, rt, locale } = useI18n();
const localePath = useLocalePath();
const api = useApi();
const { categories, load } = useTaxonomy();
const { tx } = useFormat();
await load().catch(() => undefined);

const { data: featured } = await useAsyncData(`featured:${locale.value}`, () => api<ProfessionalCardDto[]>('/professionals/featured', { query: { lang: locale.value } }), { default: () => [] });

useSeoMeta({ title: () => t('home.metaTitle'), description: () => t('home.metaDescription'), ogTitle: () => t('home.metaTitle'), ogDescription: () => t('home.metaDescription') });

function onSearch(q: { category?: string; location?: string }) {
  navigateTo(localePath({ path: '/professionals', query: { ...q } }));
}
const steps = computed(() => [
  { icon: Search, title: t('home.steps.1.title'), text: t('home.steps.1.text') },
  { icon: MessageCircleReply, title: t('home.steps.2.title'), text: t('home.steps.2.text') },
  { icon: ClipboardCheck, title: t('home.steps.3.title'), text: t('home.steps.3.text') },
]);
const faq = computed(() => (tm('faq.items') as any[]).slice(0, 4).map((i) => ({ q: rt(i.q), a: rt(i.a) })));
</script>

<template>
  <div>
    <!-- Hero -->
    <section class="bg-surface">
      <div class="container-page grid items-center gap-10 py-10 md:py-16 lg:grid-cols-[1.05fr_0.95fr] lg:gap-14">
        <div>
          <h1 class="text-[2.1rem] font-semibold leading-[1.15] md:text-5xl md:leading-[1.1]">{{ t('home.heroTitle') }}</h1>
          <p class="mt-4 max-w-xl text-lg text-[#475467] md:text-xl">{{ t('home.heroText') }}</p>
          <div class="mt-8">
            <AppSearchBar @search="onSearch" />
          </div>
          <ul class="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4" :aria-label="t('home.categoriesLabel')">
            <li v-for="c in categories ?? []" :key="c.id">
              <NuxtLink
                :to="localePath({ path: '/professionals', query: { category: c.slug } })"
                class="flex h-full flex-col gap-2 rounded-[var(--radius-card)] border border-line bg-surface p-3.5 transition-colors hover:border-primary hover:bg-primary-soft/40"
              >
                <span class="flex size-10 items-center justify-center rounded-xl bg-primary-soft text-primary"><AppCategoryIcon :slug="c.slug" class="size-5" /></span>
                <span class="text-[0.9375rem] font-medium leading-snug">{{ tx(c.name) }}</span>
              </NuxtLink>
            </li>
          </ul>
        </div>
        <AppHeroArt class="hidden md:block" />
      </div>
    </section>

    <!-- Real professionals -->
    <section v-if="featured.length" class="container-page mt-16 md:mt-20" aria-labelledby="featured-h">
      <div class="mb-6 flex items-end justify-between gap-4">
        <div>
          <h2 id="featured-h" class="text-2xl font-semibold md:text-3xl">{{ t('home.featuredTitle') }}</h2>
          <p class="mt-1 text-muted">{{ t('home.featuredText') }}</p>
        </div>
        <NuxtLink :to="localePath('/professionals')" class="hidden shrink-0 items-center gap-1 font-medium text-primary hover:underline sm:inline-flex">
          {{ t('home.seeAll') }} <ArrowRight class="size-4" aria-hidden="true" />
        </NuxtLink>
      </div>
      <div class="grid gap-4">
        <AppProfessionalCard v-for="p in featured.slice(0, 3)" :key="p.id" :pro="p" heading-level="h3" />
      </div>
      <UiButton variant="secondary" :to="localePath('/professionals')" block class="mt-4 sm:hidden">{{ t('home.seeAll') }}</UiButton>
    </section>

    <!-- How it works -->
    <section class="container-page mt-16 md:mt-24" aria-labelledby="how-h">
      <h2 id="how-h" class="text-2xl font-semibold md:text-3xl">{{ t('home.howTitle') }}</h2>
      <ol class="mt-6 grid gap-4 md:grid-cols-3">
        <li v-for="(s, i) in steps" :key="i" class="card p-6">
          <div class="flex items-center gap-3">
            <span class="flex size-10 items-center justify-center rounded-full bg-primary text-white"><component :is="s.icon" class="size-5" aria-hidden="true" /></span>
            <span class="text-sm font-medium text-muted">{{ t('home.stepN', { n: i + 1 }) }}</span>
          </div>
          <h3 class="mt-4 text-lg font-semibold">{{ s.title }}</h3>
          <p class="mt-2 text-[#475467]">{{ s.text }}</p>
        </li>
      </ol>
      <p class="mt-4 text-sm text-muted">{{ t('home.howNote') }}</p>
    </section>

    <!-- Verification -->
    <section class="container-page mt-16 md:mt-24" aria-labelledby="trust-h">
      <div class="grid gap-8 rounded-[22px] bg-primary-soft p-6 md:grid-cols-[0.9fr_1.1fr] md:p-10">
        <div>
          <h2 id="trust-h" class="text-2xl font-semibold md:text-3xl">{{ t('home.trustTitle') }}</h2>
          <p class="mt-3 text-[#344054]">{{ t('home.trustText') }}</p>
          <UiButton variant="secondary" :to="localePath('/trust')" class="mt-6">{{ t('home.trustMore') }}</UiButton>
        </div>
        <ul class="grid gap-3">
          <li class="flex gap-4 rounded-[var(--radius-card)] bg-surface p-4">
            <ShieldCheck class="mt-0.5 size-6 shrink-0 text-primary" aria-hidden="true" />
            <div><p class="font-medium">{{ t('verification.kind.IDENTITY') }}</p><p class="text-[0.9375rem] text-muted">{{ t('home.trust.identity') }}</p></div>
          </li>
          <li class="flex gap-4 rounded-[var(--radius-card)] bg-surface p-4">
            <BadgeCheck class="mt-0.5 size-6 shrink-0 text-success" aria-hidden="true" />
            <div><p class="font-medium">{{ t('home.trust.qualTitle') }}</p><p class="text-[0.9375rem] text-muted">{{ t('home.trust.qual') }}</p></div>
          </li>
          <li class="flex gap-4 rounded-[var(--radius-card)] bg-surface p-4">
            <FileSearch class="mt-0.5 size-6 shrink-0 text-[#9a4a2a]" aria-hidden="true" />
            <div><p class="font-medium">{{ t('home.trust.limitsTitle') }}</p><p class="text-[0.9375rem] text-muted">{{ t('home.trust.limits') }}</p></div>
          </li>
        </ul>
      </div>
    </section>

    <!-- Become a professional -->
    <section class="container-page mt-16 md:mt-24" aria-labelledby="pro-h">
      <div class="card flex flex-col gap-6 p-6 md:flex-row md:items-center md:justify-between md:p-10">
        <div class="max-w-2xl">
          <h2 id="pro-h" class="text-2xl font-semibold md:text-3xl">{{ t('home.proTitle') }}</h2>
          <p class="mt-3 text-[#475467]">{{ t('home.proText') }}</p>
        </div>
        <UiButton size="lg" :to="localePath('/become-a-professional')" class="shrink-0">{{ t('nav.becomePro') }}</UiButton>
      </div>
    </section>

    <!-- FAQ -->
    <section class="container-page mt-16 md:mt-24" aria-labelledby="faq-h">
      <div class="grid gap-8 md:grid-cols-[0.8fr_1.2fr]">
        <div>
          <h2 id="faq-h" class="text-2xl font-semibold md:text-3xl">{{ t('faq.title') }}</h2>
          <NuxtLink :to="localePath('/faq')" class="mt-3 inline-flex items-center gap-1 font-medium text-primary hover:underline">{{ t('home.allQuestions') }} <ArrowRight class="size-4" aria-hidden="true" /></NuxtLink>
        </div>
        <AppFaq :items="faq" />
      </div>
    </section>
  </div>
</template>
